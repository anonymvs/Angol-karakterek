
import java.util.*;

/**
 * 
 */
public class ONeill {

    /**
     * Default constructor
     */
    public ONeill() {
    }

    /**
     * 
     */
    private Direction dir;
    private Box box;

    /**
     * 
     */
    private Floor oneill;


    /**
     * 
     */
    public void move() {
        // TODO implement here
    }

    /**
     * 
     */
    public void boxing() {
        // TODO implement here
    }

    /**
     * @param Box
     */
    public void setBox( Box b ) {
        box = b;
    }

    /**
     * 
     */
    public void kill() {
        // TODO implement here
    }

    /**
     * 
     */
    public void shoot() {
        // TODO implement here
    }

}