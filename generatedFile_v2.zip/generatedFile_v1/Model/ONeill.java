
import java.util.*;

/**
 * 
 */
public class ONeill {

    /**
     * Default constructor
     */
    public ONeill() {
    }

    /**
     * 
     */
    private Direction dir;

    /**
     * 
     */
    private Floor oneill;


    /**
     * 
     */
    public void move() {
        // TODO implement here
    }

    /**
     * 
     */
    public void boxing() {
        // TODO implement here
    }

    /**
     * @param Box
     */
    public void setBox(void Box) {
        // TODO implement here
    }

    /**
     * 
     */
    public void kill() {
        // TODO implement here
    }

    /**
     * 
     */
    public void shoot() {
        // TODO implement here
    }

}