
import java.util.*;

/**
 * 
 */
public class Missile {

    /**
     * Default constructor
     */
    public Missile() {
    }

    /**
     * 
     */
    private Direction dir;

    /**
     * 
     */
    private Timer timer;

    /**
     * 
     */
    private Color color;

    /**
     * 
     */
    private LevelEntity missile;

    /**
     * 
     */
    private LevelEntity missile;

    /**
     * @param Color 
     * @param Direction
     */
    public void Missile(void Color, void Direction) {
        // TODO implement here
    }

    /**
     * 
     */
    public void move() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Color getColor() {
        // TODO implement here
        return null;
    }

}