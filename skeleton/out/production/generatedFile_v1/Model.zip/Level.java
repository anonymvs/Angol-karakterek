
import java.util.*;

/**
 * 
 */
public class Level {

    /**
     * Default constructor
     */
    public Level() {
    }

    /**
     * 
     */
    private Timer timer;

    /**
     * 
     */
    private int zpmCount;


    /**
     * 
     */
    public void Level() {
        // TODO implement here
    }

    /**
     * 
     */
    public void load() {
        // TODO implement here
    }

    /**
     * 
     */
    public void reset() {
        // TODO implement here
    }

    /**
     * 
     */
    public void decreaseZPM() {
        // TODO implement here
    }

    /**
     * 
     */
    public void endOfGame() {
        // TODO implement here
    }

}