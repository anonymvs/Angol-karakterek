
import java.util.*;

/**
 * 
 */
public class Portal extends Wall {

    /**
     * Default constructor
     */
    public Portal() {
    }

    /**
     * 
     */
    private static Portal bluePortal;

    /**
     * 
     */
    private static Portal yellowPortal;

    /**
     * 
     */
    private Direction dir;

    /**
     * 
     */
    private Wall portal;

    /**
     * @param Missile 
     * @param Wall
     */
    public void Portal(void Missile, void Wall) {
        // TODO implement here
    }

    /**
     * 
     */
    public void close() {
        // TODO implement here
    }

    /**
     * @return
     */
    public Direction getDir() {
        // TODO implement here
        return null;
    }

}