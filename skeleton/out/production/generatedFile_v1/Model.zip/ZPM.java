
import java.util.*;

/**
 * 
 */
public class ZPM {

    /**
     * Default constructor
     */
    public ZPM() {
    }

    /**
     * 
     */
    private Floor zpm;


    /**
     * @param Level
     */
    public void ZPM(void Level) {
        // TODO implement here
    }

    /**
     * 
     */
    public void collect() {
        // TODO implement here
    }

}