
import java.util.*;

/**
 * 
 */
public class Box extends Placeable {

    /**
     * Default constructor
     */
    public Box() {
    }

    /**
     * @param ONeill 
     * @param Box 
     * @return
     */
    public abstract bool boxEvent(void ONeill, void Box);

    /**
     * @param ONeill
     */
    public abstract void moveEvent(void ONeill);

}